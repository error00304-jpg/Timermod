package com.example.countdowntimer.client;

import com.example.countdowntimer.Animation;
import com.example.countdowntimer.TimerSyncPacket;

/** Copia local del contador. No usa clases de Minecraft, solo datos. */
public class ClientTimerState {
    public static int remaining = 0, total = 0, color = 0xFFFFFF, y = 24;
    public static boolean running = false, visible = false, background = true;
    public static String title = "";
    public static Animation animation = Animation.PULSE;
    public static float scale = 2.0f;
    public static int animTicks = 0;

    public static void apply(TimerSyncPacket p) {
        remaining = p.ticksRemaining;
        total = p.totalTicks;
        color = p.color;
        y = p.y;
        running = p.running;
        visible = p.visible;
        background = p.background;
        title = p.title;
        animation = Animation.byId(p.animation);
        scale = p.scale;
    }

    public static void tick() {
        if (running && remaining > 0) remaining--;
    }

    public static void clear() {
        remaining = 0;
        total = 0;
        running = false;
        visible = false;
        title = "";
    }
}
