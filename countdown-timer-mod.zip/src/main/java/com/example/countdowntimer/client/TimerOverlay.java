package com.example.countdowntimer.client;

import com.example.countdowntimer.Animation;
import com.example.countdowntimer.TimerData;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.ForgeGui;

public class TimerOverlay {

    public static void render(ForgeGui gui, GuiGraphics g, float pt, int sw, int sh) {
        if (!ClientTimerState.visible) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui) return;
        Font font = mc.font;
        PoseStack pose = g.pose();

        boolean live = ClientTimerState.running && ClientTimerState.remaining > 0;
        float rem = live ? Math.max(0f, ClientTimerState.remaining - pt) : ClientTimerState.remaining;
        int secs = (int) Math.ceil(rem / 20.0);
        String text = TimerData.format(secs);

        float t = ClientTimerState.animTicks + pt;
        float f = (rem % 20f) / 20f;           // 1 = acaba de cambiar el segundo, 0 = a punto de cambiar
        if (f == 0f && rem > 0f) f = 1f;

        boolean urgent = ClientTimerState.running && rem > 0f && secs <= 10;
        boolean finished = rem <= 0f && ClientTimerState.total > 0;

        Animation anim = ClientTimerState.animation;
        float scale = ClientTimerState.scale;
        int rgb = ClientTimerState.color;
        float dx = 0f, dy = 0f;
        boolean drawTimer = true;

        switch (anim) {
            case PULSE -> scale *= 1f + 0.25f * f * f;
            case SHAKE -> {
                float amp = (urgent || finished) ? 2.5f : 0.8f;
                dx = (float) Math.sin(t * 2.7f) * amp;
                dy = (float) Math.cos(t * 3.3f) * amp;
            }
            case BLINK -> { if (urgent && f < 0.35f) drawTimer = false; }
            case RAINBOW -> rgb = Mth.hsvToRgb((t * 0.01f) % 1f, 0.7f, 1f);
            default -> { }
        }
        if (finished && anim != Animation.NONE) {
            rgb = ((ClientTimerState.animTicks / 8) % 2 == 0) ? 0xFF3333 : 0xFFFFFF;
        }

        float baseY = ClientTimerState.y;

        // ----- titulo -----
        float titleH = 0f;
        String title = ClientTimerState.title;
        if (!title.isEmpty()) {
            float ts = Math.max(1f, ClientTimerState.scale * 0.75f);
            String ttl = TimerData.formatCodes(title);
            pose.pushPose();
            pose.translate(sw / 2f, baseY, 0f);
            pose.scale(ts, ts, 1f);
            g.drawString(font, ttl, -font.width(ttl) / 2, 0, 0xFFFFFFFF, true);
            pose.popPose();
            titleH = 9f * ts + 4f;
        }

        // ----- contador -----
        if (!drawTimer) return;
        float centerY = baseY + titleH + 4f * ClientTimerState.scale + 4f;

        pose.pushPose();
        pose.translate(sw / 2f + dx, centerY + dy, 0f);
        pose.scale(scale, scale, 1f);
        int tw = font.width(text);
        if (ClientTimerState.background) {
            g.fill(-tw / 2 - 5, -7, tw / 2 + 5, 8, 0xAA000000);
            g.renderOutline(-tw / 2 - 5, -7, tw + 10, 15, 0x66FFFFFF);
        }
        g.drawString(font, text, -tw / 2, -4, 0xFF000000 | rgb, true);
        pose.popPose();
    }
}
