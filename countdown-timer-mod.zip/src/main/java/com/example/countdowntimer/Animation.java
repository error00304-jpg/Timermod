package com.example.countdowntimer;

public enum Animation {
    NONE, PULSE, SHAKE, BLINK, RAINBOW;

    public static Animation byId(int id) {
        Animation[] v = values();
        return v[Math.floorMod(id, v.length)];
    }

    public static Animation byName(String name) {
        for (Animation a : values()) {
            if (a.name().equalsIgnoreCase(name)) return a;
        }
        return null;
    }
}
