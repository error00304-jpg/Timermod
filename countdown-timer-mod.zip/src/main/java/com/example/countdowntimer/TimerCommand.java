package com.example.countdowntimer;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.util.Arrays;
import java.util.function.Consumer;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CountdownMod.MODID)
public class TimerCommand {
    private static final int MAX = 359999; // 99:59:59

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();

        d.register(Commands.literal("timer")
            .requires(s -> s.hasPermission(2))

            // ---- tiempo ----
            .then(Commands.literal("set")
                .then(Commands.argument("seconds", IntegerArgumentType.integer(0, MAX))
                    .executes(c -> setTime(c, IntegerArgumentType.getInteger(c, "seconds"), false))))
            .then(Commands.literal("setmin")
                .then(Commands.argument("minutes", IntegerArgumentType.integer(0, 5999))
                    .then(Commands.argument("seconds", IntegerArgumentType.integer(0, 59))
                        .executes(c -> setTime(c,
                            IntegerArgumentType.getInteger(c, "minutes") * 60
                                + IntegerArgumentType.getInteger(c, "seconds"), false)))))
            .then(Commands.literal("add")
                .then(Commands.argument("seconds", IntegerArgumentType.integer(1, MAX))
                    .executes(c -> addTime(c, IntegerArgumentType.getInteger(c, "seconds")))))
            .then(Commands.literal("remove")
                .then(Commands.argument("seconds", IntegerArgumentType.integer(1, MAX))
                    .executes(c -> addTime(c, -IntegerArgumentType.getInteger(c, "seconds")))))

            // ---- control ----
            .then(Commands.literal("start")
                .executes(TimerCommand::start)
                .then(Commands.argument("seconds", IntegerArgumentType.integer(1, MAX))
                    .executes(c -> setTime(c, IntegerArgumentType.getInteger(c, "seconds"), true))))
            .then(simple("pause", d0 -> d0.running = false, "Contador en pausa."))
            .then(Commands.literal("resume").executes(c -> run(c,
                d0 -> { if (d0.ticksRemaining > 0) { d0.running = true; d0.visible = true; } },
                "Contador reanudado.")))
            .then(simple("reset", d0 -> { d0.running = false; d0.ticksRemaining = d0.totalTicks; },
                "Contador reiniciado."))
            .then(simple("stop", d0 -> { d0.running = false; d0.visible = false; d0.ticksRemaining = d0.totalTicks; },
                "Contador detenido y oculto."))
            .then(simple("show", d0 -> d0.visible = true, "Contador visible."))
            .then(simple("hide", d0 -> d0.visible = false, "Contador oculto."))

            // ---- apariencia / animacion ----
            .then(Commands.literal("title")
                .then(Commands.argument("text", StringArgumentType.greedyString())
                    .executes(c -> {
                        String t = StringArgumentType.getString(c, "text");
                        return run(c, d0 -> d0.title = t, "Titulo actualizado.");
                    })))
            .then(simple("cleartitle", d0 -> d0.title = "", "Titulo borrado."))
            .then(Commands.literal("color")
                .then(Commands.argument("hex", StringArgumentType.word())
                    .executes(c -> {
                        try {
                            int rgb = Integer.parseInt(StringArgumentType.getString(c, "hex"), 16) & 0xFFFFFF;
                            return run(c, d0 -> d0.color = rgb, "Color cambiado.");
                        } catch (NumberFormatException ex) {
                            c.getSource().sendFailure(Component.literal("Color invalido. Usa hex sin #, ej: ff0000"));
                            return 0;
                        }
                    })))
            .then(Commands.literal("animation")
                .then(Commands.argument("type", StringArgumentType.word())
                    .suggests((ctx, b) -> SharedSuggestionProvider.suggest(
                        Arrays.stream(Animation.values()).map(a -> a.name().toLowerCase()), b))
                    .executes(c -> {
                        Animation a = Animation.byName(StringArgumentType.getString(c, "type"));
                        if (a == null) {
                            c.getSource().sendFailure(Component.literal("Animacion invalida: none, pulse, shake, blink, rainbow"));
                            return 0;
                        }
                        return run(c, d0 -> d0.animation = a, "Animacion: " + a.name().toLowerCase());
                    })))
            .then(Commands.literal("scale")
                .then(Commands.argument("value", FloatArgumentType.floatArg(0.5f, 10f))
                    .executes(c -> {
                        float v = FloatArgumentType.getFloat(c, "value");
                        return run(c, d0 -> d0.scale = v, "Tamano: " + v);
                    })))
            .then(Commands.literal("y")
                .then(Commands.argument("pixels", IntegerArgumentType.integer(0, 2000))
                    .executes(c -> {
                        int v = IntegerArgumentType.getInteger(c, "pixels");
                        return run(c, d0 -> d0.y = v, "Posicion Y: " + v);
                    })))
            .then(Commands.literal("background")
                .then(Commands.argument("enabled", BoolArgumentType.bool())
                    .executes(c -> {
                        boolean v = BoolArgumentType.getBool(c, "enabled");
                        return run(c, d0 -> d0.background = v, "Fondo: " + v);
                    })))
            .then(Commands.literal("beep")
                .then(Commands.argument("enabled", BoolArgumentType.bool())
                    .executes(c -> {
                        boolean v = BoolArgumentType.getBool(c, "enabled");
                        return run(c, d0 -> d0.beep = v, "Pitido ultimos 10s: " + v);
                    })))

            // ---- al terminar ----
            .then(Commands.literal("endmessage")
                .then(Commands.argument("text", StringArgumentType.greedyString())
                    .executes(c -> {
                        String t = StringArgumentType.getString(c, "text");
                        return run(c, d0 -> d0.endMessage = t, "Mensaje final actualizado.");
                    })))
            .then(simple("clearendmessage", d0 -> d0.endMessage = "", "Mensaje final borrado."))
            .then(Commands.literal("onend")
                .then(Commands.argument("command", StringArgumentType.greedyString())
                    .executes(c -> {
                        String t = StringArgumentType.getString(c, "command");
                        return run(c, d0 -> d0.endCommand = t, "Al terminar se ejecutara: " + t);
                    })))
            .then(simple("clearonend", d0 -> d0.endCommand = "", "Comando final borrado."))

            // ---- info ----
            .then(Commands.literal("status").executes(c -> {
                TimerData t = TimerManager.data;
                c.getSource().sendSuccess(() -> Component.literal(
                    "Restante " + TimerData.format((int) Math.ceil(t.ticksRemaining / 20.0))
                    + " / total " + TimerData.format(t.totalTicks / 20)
                    + " | corriendo=" + t.running + " visible=" + t.visible
                    + " anim=" + t.animation.name().toLowerCase()
                    + " escala=" + t.scale), false);
                return 1;
            }))
        );
    }

    private static LiteralArgumentBuilder<CommandSourceStack> simple(String name, Consumer<TimerData> change, String msg) {
        return Commands.literal(name).executes(c -> run(c, change, msg));
    }

    private static int run(CommandContext<CommandSourceStack> c, Consumer<TimerData> change, String msg) {
        change.accept(TimerManager.data);
        TimerManager.sync();
        c.getSource().sendSuccess(() -> Component.literal(msg), true);
        return 1;
    }

    private static int setTime(CommandContext<CommandSourceStack> c, int secs, boolean start) {
        int ticks = secs * 20;
        return run(c, d -> {
            d.totalTicks = ticks;
            d.ticksRemaining = ticks;
            d.visible = true;
            d.running = start && ticks > 0;
        }, (start ? "Contador iniciado en " : "Contador fijado en ") + TimerData.format(secs));
    }

    private static int addTime(CommandContext<CommandSourceStack> c, int deltaSecs) {
        return run(c, d -> {
            d.ticksRemaining = Math.max(0, Math.min(MAX * 20, d.ticksRemaining + deltaSecs * 20));
            d.totalTicks = Math.max(d.totalTicks, d.ticksRemaining);
        }, (deltaSecs >= 0 ? "Sumados " : "Restados ") + Math.abs(deltaSecs) + "s");
    }

    private static int start(CommandContext<CommandSourceStack> c) {
        TimerData t = TimerManager.data;
        if (t.ticksRemaining <= 0 && t.totalTicks <= 0) {
            c.getSource().sendFailure(Component.literal("Primero define el tiempo: /timer set <segundos>"));
            return 0;
        }
        return run(c, d -> {
            if (d.ticksRemaining <= 0) d.ticksRemaining = d.totalTicks;
            d.running = true;
            d.visible = true;
        }, "Contador iniciado.");
    }
}
