package com.example.countdowntimer;

import com.example.countdowntimer.client.ClientTimerState;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

public class TimerSyncPacket {
    public final int ticksRemaining, totalTicks, color, y, animation;
    public final boolean running, visible, background;
    public final float scale;
    public final String title;

    public TimerSyncPacket(TimerData d) {
        this.ticksRemaining = d.ticksRemaining;
        this.totalTicks = d.totalTicks;
        this.color = d.color;
        this.y = d.y;
        this.animation = d.animation.ordinal();
        this.running = d.running;
        this.visible = d.visible;
        this.background = d.background;
        this.scale = d.scale;
        this.title = d.title;
    }

    private TimerSyncPacket(FriendlyByteBuf b) {
        this.ticksRemaining = b.readVarInt();
        this.totalTicks = b.readVarInt();
        this.color = b.readInt();
        this.y = b.readVarInt();
        this.animation = b.readVarInt();
        this.running = b.readBoolean();
        this.visible = b.readBoolean();
        this.background = b.readBoolean();
        this.scale = b.readFloat();
        this.title = b.readUtf();
    }

    public static void encode(TimerSyncPacket p, FriendlyByteBuf b) {
        b.writeVarInt(p.ticksRemaining);
        b.writeVarInt(p.totalTicks);
        b.writeInt(p.color);
        b.writeVarInt(p.y);
        b.writeVarInt(p.animation);
        b.writeBoolean(p.running);
        b.writeBoolean(p.visible);
        b.writeBoolean(p.background);
        b.writeFloat(p.scale);
        b.writeUtf(p.title);
    }

    public static TimerSyncPacket decode(FriendlyByteBuf b) {
        return new TimerSyncPacket(b);
    }

    public static void handle(TimerSyncPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> ClientTimerState.apply(p));
        ctx.get().setPacketHandled(true);
    }
}
