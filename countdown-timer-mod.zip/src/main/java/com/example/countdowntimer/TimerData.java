package com.example.countdowntimer;

/** Estado del contador (lado servidor). Se sincroniza a los clientes con TimerSyncPacket. */
public class TimerData {
    public int ticksRemaining = 0;
    public int totalTicks = 0;
    public boolean running = false;
    public boolean visible = false;
    public boolean background = true;
    public boolean beep = true;
    public String title = "";
    public String endMessage = "&c&l\u00a1TIEMPO!";
    public String endCommand = "";
    public int color = 0xFFFFFF;
    public Animation animation = Animation.PULSE;
    public float scale = 2.0f;
    public int y = 24;

    public static String formatCodes(String s) {
        return s.replace('&', '\u00a7');
    }

    public static String format(int secs) {
        int h = secs / 3600, m = (secs % 3600) / 60, s = secs % 60;
        return h > 0 ? String.format("%d:%02d:%02d", h, m, s) : String.format("%02d:%02d", m, s);
    }
}
