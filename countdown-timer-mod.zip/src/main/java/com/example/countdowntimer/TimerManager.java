package com.example.countdowntimer;

import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

@Mod.EventBusSubscriber(modid = CountdownMod.MODID)
public class TimerManager {
    public static TimerData data = new TimerData();

    public static void sync() {
        Network.CHANNEL.send(PacketDistributor.ALL.noArg(), new TimerSyncPacket(data));
    }

    @SubscribeEvent
    public static void onServerStarting(ServerStartingEvent e) {
        data = new TimerData();
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            Network.CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new TimerSyncPacket(data));
        }
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !data.running) return;
        MinecraftServer server = e.getServer();

        if (data.ticksRemaining > 0) data.ticksRemaining--;

        if (data.ticksRemaining <= 0) {
            data.ticksRemaining = 0;
            data.running = false;
            sync();
            finish(server);
            return;
        }

        if (data.ticksRemaining % 20 == 0) {
            int secs = data.ticksRemaining / 20;
            if (data.beep && secs <= 10) {
                for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                    p.playNotifySound(SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.MASTER,
                            0.7f, secs <= 3 ? 1.6f : 1.0f);
                }
            }
            sync(); // correccion de deriva cada segundo
        }
    }

    private static void finish(MinecraftServer server) {
        boolean hasMsg = !data.endMessage.isEmpty();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (hasMsg) {
                p.connection.send(new ClientboundSetTitlesAnimationPacket(5, 60, 20));
                p.connection.send(new ClientboundSetTitleTextPacket(
                        Component.literal(TimerData.formatCodes(data.endMessage))));
            }
            p.playNotifySound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.MASTER, 1f, 1f);
        }
        String cmd = data.endCommand;
        if (cmd != null && !cmd.isBlank()) {
            if (cmd.startsWith("/")) cmd = cmd.substring(1);
            server.getCommands().performPrefixedCommand(server.createCommandSourceStack(), cmd);
        }
    }
}
