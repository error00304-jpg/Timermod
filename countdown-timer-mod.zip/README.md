# Countdown Timer (Forge 1.20.1)

Contador regresivo en pantalla, controlado con comandos, con animaciones y sincronizado para todos los jugadores.

## Compilar en GitHub Codespaces

1. Sube `countdown-timer-mod.zip` al Explorador del Codespace (arrastrar y soltar) en la raiz del repo.
2. `unzip -o countdown-timer-mod.zip && rm countdown-timer-mod.zip`
3. `bash setup.sh`   (genera el Gradle Wrapper y compila)
4. El mod queda en `build/libs/countdowntimer-1.0.0.jar` -> clic derecho -> **Download**.
5. `git add . && git commit -m "init" && git push`  (GitHub Actions tambien compila y guarda el .jar como artifact)

Requiere Java 17. Si el Codespace no lo trae: `sdk install java 17.0.12-tem && sdk use java 17.0.12-tem`.

Para probar el mod dentro del Codespace sin Minecraft cliente: `./gradlew runServer` (acepta el EULA en `run/eula.txt`).

## Comandos (`/timer`, permiso nivel 2 / OP)

| Comando | Que hace |
|---|---|
| `/timer set <segundos>` | Fija el tiempo (no inicia) |
| `/timer setmin <min> <seg>` | Fija el tiempo en min:seg |
| `/timer start [segundos]` | Inicia (opcionalmente fijando segundos) |
| `/timer pause` / `resume` | Pausa / reanuda |
| `/timer add <s>` / `remove <s>` | Suma / resta segundos en vivo |
| `/timer reset` / `stop` | Reinicia / detiene y oculta |
| `/timer show` / `hide` | Muestra / oculta |
| `/timer title <texto>` / `cleartitle` | Texto sobre el contador (acepta `&c`, `&l`, etc.) |
| `/timer color <hex>` | Color, ej. `ff0000` |
| `/timer animation <none\|pulse\|shake\|blink\|rainbow>` | Animacion |
| `/timer scale <0.5-10>` | Tamano |
| `/timer y <pixeles>` | Posicion vertical |
| `/timer background <true\|false>` | Caja oscura detras |
| `/timer beep <true\|false>` | Pitido en los ultimos 10 s |
| `/timer endmessage <texto>` / `clearendmessage` | Titulo grande al llegar a 0 |
| `/timer onend <comando>` / `clearonend` | Comando que se ejecuta al llegar a 0 (ej. `give @a diamond 1`) |
| `/timer status` | Estado actual |

Ejemplo:
```
/timer title &e&lELLA LE REGALA ESTO A...
/timer setmin 3 33
/timer animation pulse
/timer onend give @a minecraft:diamond 5
/timer start
```

## Estructura
- `TimerManager` - logica del servidor (tick, sync, fin)
- `TimerCommand` - comandos Brigadier
- `TimerSyncPacket` / `Network` - sincronizacion al cliente
- `client/TimerOverlay` - dibujo en pantalla y animaciones
- Para agregar animaciones: anade un valor en `Animation` y un `case` en `TimerOverlay`.
